package main.java.com.ies.lab03_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab032Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab032Application.class, args);
	}

}
